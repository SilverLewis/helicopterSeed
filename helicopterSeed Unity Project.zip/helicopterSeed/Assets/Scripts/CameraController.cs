using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraController : MonoBehaviour
{
    Transform cameraPivot;

    [Space(5)]
    [Header("Seed")]
    [SerializeField] Transform seedPivot;

    [Space(5)]
    [SerializeField] float horizontalRotationSpeed=30;
    [SerializeField] float verticalRotationSpeed=30;
    [SerializeField] float cameraMaxVerticalDegrees = 75;
    [SerializeField] float cameraMinVerticalDegrees = 15;

    [SerializeField] int invertCamera = 1;



    // Start is called before the first frame update
    void Start()
    {
        cameraPivot = transform.transform;
        SetNewForward();
    }

    private void FixedUpdate()
    {
        cameraPivot.transform.position = seedPivot.transform.position;
    }

    // Update is called once per frame
    void Update()
    {
        SetNewForward();

        if (Input.GetButtonDown("invertCamera")) {
            invertCamera *=-1 ;
        }

        float vert = Input.GetAxis("VerticalCamera");
        if (vert == 0) {
            vert = Input.GetAxis("VerticalCamera2");
        }

        float hor = Input.GetAxis("HorizontalCamera");
        if (hor == 0)
        {
            hor = Input.GetAxis("HorizontalCamera2");
        }


        float verticalRotationChange = vert*invertCamera * Time.deltaTime * verticalRotationSpeed;
        float horizontalRotationChange =  hor * Time.deltaTime * horizontalRotationSpeed * invertCamera;

        Vector3 rotation =cameraPivot.rotation.eulerAngles;

        rotation.x = Mathf.Clamp(verticalRotationChange  + rotation.x , cameraMinVerticalDegrees, cameraMaxVerticalDegrees);
        rotation.y += horizontalRotationChange ;

        cameraPivot.rotation =  Quaternion.Euler(rotation);
        
    }

    void SetNewForward()
    {
        Vector3 newForward = seedPivot.transform.position-transform.GetChild(0).position;
        newForward.y = 0;
        seedPivot.GetComponent<SeedMovement>().forwardVector =Vector3.Normalize(newForward);
    }

}
